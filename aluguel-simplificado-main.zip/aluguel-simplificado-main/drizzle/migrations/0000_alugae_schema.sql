-- Enum de status de reserva
CREATE TYPE public.reserva_status AS ENUM ('pendente','aprovada','recusada','cancelada','em_andamento','devolvido','concluida');
CREATE TYPE public.pagamento_status AS ENUM ('pendente','pago','reembolsado');

-- PROFILES
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  nome TEXT NOT NULL DEFAULT '',
  bio TEXT,
  telefone TEXT,
  cidade TEXT,
  bairro TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT ON public.profiles TO anon;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "perfis visiveis a todos" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "usuario cria seu perfil" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "usuario edita seu perfil" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id);

-- CATEGORIAS
CREATE TABLE public.categorias (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nome TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE
);
GRANT SELECT ON public.categorias TO anon, authenticated;
GRANT ALL ON public.categorias TO service_role;
ALTER TABLE public.categorias ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categorias publicas" ON public.categorias FOR SELECT USING (true);

-- ITENS
CREATE TABLE public.itens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  locador_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  categoria_id UUID REFERENCES public.categorias(id) ON DELETE SET NULL,
  titulo TEXT NOT NULL,
  descricao TEXT NOT NULL DEFAULT '',
  condicoes_uso TEXT,
  preco_dia NUMERIC(10,2) NOT NULL CHECK (preco_dia >= 0),
  cidade TEXT NOT NULL DEFAULT 'Fortaleza',
  bairro TEXT,
  imagem_url TEXT,
  ativo BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.itens TO authenticated;
GRANT SELECT ON public.itens TO anon;
GRANT ALL ON public.itens TO service_role;
ALTER TABLE public.itens ENABLE ROW LEVEL SECURITY;
CREATE POLICY "itens ativos publicos" ON public.itens FOR SELECT USING (ativo = true);
CREATE POLICY "locador ve seus itens" ON public.itens FOR SELECT TO authenticated USING (auth.uid() = locador_id);
CREATE POLICY "locador cria item" ON public.itens FOR INSERT TO authenticated WITH CHECK (auth.uid() = locador_id);
CREATE POLICY "locador edita item" ON public.itens FOR UPDATE TO authenticated USING (auth.uid() = locador_id);
CREATE POLICY "locador apaga item" ON public.itens FOR DELETE TO authenticated USING (auth.uid() = locador_id);
CREATE INDEX itens_categoria_idx ON public.itens(categoria_id);
CREATE INDEX itens_locador_idx ON public.itens(locador_id);

-- IMAGENS DO ITEM
CREATE TABLE public.item_imagens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id UUID NOT NULL REFERENCES public.itens(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  ordem INT NOT NULL DEFAULT 0
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.item_imagens TO authenticated;
GRANT SELECT ON public.item_imagens TO anon;
GRANT ALL ON public.item_imagens TO service_role;
ALTER TABLE public.item_imagens ENABLE ROW LEVEL SECURITY;
CREATE POLICY "imagens publicas" ON public.item_imagens FOR SELECT USING (true);
CREATE POLICY "locador gerencia imagens" ON public.item_imagens FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.itens i WHERE i.id = item_id AND i.locador_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.itens i WHERE i.id = item_id AND i.locador_id = auth.uid()));

-- DISPONIBILIDADE
CREATE TABLE public.disponibilidades (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id UUID NOT NULL REFERENCES public.itens(id) ON DELETE CASCADE,
  data_inicio DATE NOT NULL,
  data_fim DATE NOT NULL,
  CHECK (data_fim >= data_inicio)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.disponibilidades TO authenticated;
GRANT SELECT ON public.disponibilidades TO anon;
GRANT ALL ON public.disponibilidades TO service_role;
ALTER TABLE public.disponibilidades ENABLE ROW LEVEL SECURITY;
CREATE POLICY "disponibilidade publica" ON public.disponibilidades FOR SELECT USING (true);
CREATE POLICY "locador gerencia disponibilidade" ON public.disponibilidades FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.itens i WHERE i.id = item_id AND i.locador_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.itens i WHERE i.id = item_id AND i.locador_id = auth.uid()));

-- RESERVAS
CREATE TABLE public.reservas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id UUID NOT NULL REFERENCES public.itens(id) ON DELETE CASCADE,
  locatario_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  locador_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  data_inicio DATE NOT NULL,
  data_fim DATE NOT NULL,
  valor_total NUMERIC(10,2) NOT NULL DEFAULT 0,
  status public.reserva_status NOT NULL DEFAULT 'pendente',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (data_fim >= data_inicio)
);
GRANT SELECT, INSERT, UPDATE ON public.reservas TO authenticated;
GRANT ALL ON public.reservas TO service_role;
ALTER TABLE public.reservas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "partes veem reserva" ON public.reservas FOR SELECT TO authenticated
  USING (auth.uid() = locatario_id OR auth.uid() = locador_id);
CREATE POLICY "locatario cria reserva" ON public.reservas FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = locatario_id AND auth.uid() <> locador_id);
CREATE POLICY "partes atualizam reserva" ON public.reservas FOR UPDATE TO authenticated
  USING (auth.uid() = locatario_id OR auth.uid() = locador_id);
CREATE INDEX reservas_item_idx ON public.reservas(item_id);

-- PAGAMENTOS
CREATE TABLE public.pagamentos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reserva_id UUID NOT NULL UNIQUE REFERENCES public.reservas(id) ON DELETE CASCADE,
  valor NUMERIC(10,2) NOT NULL,
  metodo TEXT NOT NULL DEFAULT 'pix',
  status public.pagamento_status NOT NULL DEFAULT 'pendente',
  pago_em TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.pagamentos TO authenticated;
GRANT ALL ON public.pagamentos TO service_role;
ALTER TABLE public.pagamentos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "partes veem pagamento" ON public.pagamentos FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.reservas r WHERE r.id = reserva_id AND (r.locatario_id = auth.uid() OR r.locador_id = auth.uid())));
CREATE POLICY "locatario paga" ON public.pagamentos FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.reservas r WHERE r.id = reserva_id AND r.locatario_id = auth.uid()));
CREATE POLICY "locatario atualiza pagamento" ON public.pagamentos FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.reservas r WHERE r.id = reserva_id AND r.locatario_id = auth.uid()));

-- AVALIACOES
CREATE TABLE public.avaliacoes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reserva_id UUID NOT NULL REFERENCES public.reservas(id) ON DELETE CASCADE,
  autor_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  avaliado_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  item_id UUID REFERENCES public.itens(id) ON DELETE CASCADE,
  nota INT NOT NULL CHECK (nota BETWEEN 1 AND 5),
  comentario TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (reserva_id, autor_id)
);
GRANT SELECT, INSERT ON public.avaliacoes TO authenticated;
GRANT SELECT ON public.avaliacoes TO anon;
GRANT ALL ON public.avaliacoes TO service_role;
ALTER TABLE public.avaliacoes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "avaliacoes publicas" ON public.avaliacoes FOR SELECT USING (true);
CREATE POLICY "autor cria avaliacao" ON public.avaliacoes FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = autor_id AND EXISTS (
    SELECT 1 FROM public.reservas r WHERE r.id = reserva_id
      AND r.status IN ('devolvido','concluida')
      AND (r.locatario_id = auth.uid() OR r.locador_id = auth.uid())));

-- Trigger: cria perfil no cadastro
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, nome, avatar_url)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'nome', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email,'@',1)), NEW.raw_user_meta_data->>'avatar_url')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

INSERT INTO public.categorias (nome, slug) VALUES
  ('Ferramentas','ferramentas'),
  ('Eletrônicos','eletronicos'),
  ('Esporte','esporte'),
  ('Música','musica'),
  ('Festas','festas'),
  ('Lazer','lazer');
