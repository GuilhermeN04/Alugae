import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ItemCard } from "@/components/item-card";
import { listarAvaliacoesRecebidas, obterPerfil, type ItemComRelacoes } from "@/lib/alugae";

export const Route = createFileRoute("/perfil/$userId")({
  head: () => ({
    meta: [
      { title: "Perfil público — Alugaê" },
      {
        name: "description",
        content: "Reputação, avaliações recebidas e itens anunciados por este usuário no Alugaê.",
      },
      { property: "og:title", content: "Perfil público — Alugaê" },
      { property: "og:description", content: "Avaliações e itens anunciados no Alugaê." },
    ],
  }),
  component: PerfilPublico,
});

function PerfilPublico() {
  const { userId } = Route.useParams();

  const perfil = useQuery({ queryKey: ["perfil", userId], queryFn: () => obterPerfil(userId) });
  const avaliacoes = useQuery({
    queryKey: ["avaliacoes", userId],
    queryFn: () => listarAvaliacoesRecebidas(userId),
  });
  const itens = useQuery({
    queryKey: ["itens-perfil", userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("itens")
        .select("*, categorias(nome, slug), profiles!itens_locador_id_fkey(id, nome, cidade)")
        .eq("locador_id", userId)
        .eq("ativo", true);
      if (error) throw error;
      return (data ?? []) as unknown as ItemComRelacoes[];
    },
  });

  const notas = (avaliacoes.data ?? []).map((a) => a.nota);
  const media = notas.length ? notas.reduce((a, b) => a + b, 0) / notas.length : null;

  return (
    <main className="mx-auto max-w-6xl px-5 py-10">
      <section className="glass-strong rounded-3xl p-6">
        <h1 className="text-2xl font-semibold tracking-tight">
          {perfil.data?.nome ?? "Usuário do Alugaê"}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {[perfil.data?.bairro, perfil.data?.cidade].filter(Boolean).join(" · ") || "Brasil"}
        </p>
        <p className="mt-3 font-mono text-xs text-muted-foreground">
          reputação {media ? `${media.toFixed(1)} / 5` : "sem avaliações"} · {notas.length}{" "}
          avaliação(ões)
        </p>
        {perfil.data?.bio ? (
          <p className="mt-3 text-sm text-foreground/70">{perfil.data.bio}</p>
        ) : null}
      </section>

      <section className="mt-8">
        <h2 className="mb-4 text-xl font-semibold tracking-tight">Itens anunciados</h2>
        {(itens.data ?? []).length === 0 ? (
          <p className="text-sm text-muted-foreground">Nenhum item ativo no momento.</p>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {(itens.data ?? []).map((i) => (
              <ItemCard key={i.id} item={i} />
            ))}
          </div>
        )}
      </section>

      <section className="mt-10">
        <h2 className="mb-4 text-xl font-semibold tracking-tight">Avaliações recebidas</h2>
        <div className="space-y-3">
          {(avaliacoes.data ?? []).length === 0 ? (
            <p className="text-sm text-muted-foreground">Ainda sem avaliações.</p>
          ) : (
            (avaliacoes.data ?? []).map((a) => (
              <article key={a.id} className="glass rounded-2xl p-4">
                <p className="font-mono text-xs text-brand-wood">{a.nota} / 5</p>
                <p className="mt-1 text-sm text-foreground/75">{a.comentario ?? "Sem comentário."}</p>
              </article>
            ))
          )}
        </div>
      </section>
    </main>
  );
}
