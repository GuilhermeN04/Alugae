import { ExigePapel } from "@/hooks/use-papeis";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import {
  listarMeusItens,
  listarReservasComoLocador,
  moeda,
  statusLabel,
  type ReservaCompleta,
} from "@/lib/alugae";
import type { Database } from "@/integrations/supabase/types";
import { FormAvaliacao } from "@/components/form-avaliacao";

export const Route = createFileRoute("/_authenticated/painel")({
  head: () => ({
    meta: [
      { title: "Meu painel — Alugaê" },
      {
        name: "description",
        content:
          "Gerencie seus itens anunciados, aprove reservas e acompanhe seus ganhos no Alugaê.",
      },
      { property: "og:title", content: "Meu painel — Alugaê" },
      { property: "og:description", content: "Seus itens e reservas recebidas no Alugaê." },
    ],
  }),
  component: () => (
    <ExigePapel papel="locador">
      <Painel />
    </ExigePapel>
  ),
});

const proximoStatus: Record<string, { label: string; status: string }[]> = {
  pendente: [
    { label: "Aprovar", status: "aprovada" },
    { label: "Recusar", status: "recusada" },
  ],
  aprovada: [{ label: "Iniciar aluguel", status: "em_andamento" }],
  em_andamento: [{ label: "Marcar como devolvido", status: "devolvido" }],
  devolvido: [{ label: "Concluir", status: "concluida" }],
};

function Painel() {
  const { user } = useAuth();
  const userId = user?.id ?? "";
  const qc = useQueryClient();

  const itens = useQuery({
    queryKey: ["meus-itens", userId],
    queryFn: () => listarMeusItens(userId),
    enabled: !!userId,
  });

  const reservas = useQuery({
    queryKey: ["reservas-locador", userId],
    queryFn: () => listarReservasComoLocador(userId),
    enabled: !!userId,
  });

  const atualizarStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase
        .from("reservas")
        .update({ status: status as Database["public"]["Enums"]["reserva_status"] })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["reservas-locador", userId] }),
  });

  const alternarAtivo = useMutation({
    mutationFn: async ({ id, ativo }: { id: string; ativo: boolean }) => {
      const { error } = await supabase.from("itens").update({ ativo }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["meus-itens", userId] }),
  });

  const excluirItem = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("itens").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["meus-itens", userId] }),
  });

  const pagamentos = useQuery({
    queryKey: ["pagamentos-locador", userId],
    queryFn: async () => {
      const { data, error } = await supabase.from("pagamentos").select("reserva_id, status");
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!userId,
  });

  const minhasAvaliacoes = useQuery({
    queryKey: ["avaliacoes-locador", userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("avaliacoes")
        .select("reserva_id")
        .eq("autor_id", userId);
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!userId,
  });

  const reembolsar = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("reservas").update({ status: "cancelada" }).eq("id", id);
      if (error) throw error;
      const { error: e2 } = await supabase
        .from("pagamentos")
        .update({ status: "reembolsado" })
        .eq("reserva_id", id);
      if (e2) throw e2;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["reservas-locador", userId] });
      qc.invalidateQueries({ queryKey: ["pagamentos-locador", userId] });
    },
  });

  const avaliar = useMutation({
    mutationFn: async (input: {
      reservaId: string;
      avaliadoId: string;
      nota: number;
      comentario: string;
    }) => {
      const { error } = await supabase.from("avaliacoes").insert({
        reserva_id: input.reservaId,
        autor_id: userId,
        avaliado_id: input.avaliadoId,
        nota: input.nota,
        comentario: input.comentario.trim() || null,
      });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["avaliacoes-locador", userId] }),
  });

  const pagStatus = (reservaId: string) =>
    (pagamentos.data ?? []).find((p) => p.reserva_id === reservaId)?.status;
  const avaliadas = new Set((minhasAvaliacoes.data ?? []).map((a) => a.reserva_id));

  const lista = reservas.data ?? [];
  const ganhos = lista
    .filter((r) => pagStatus(r.id) === "pago")
    .reduce((soma, r) => soma + Number(r.valor_total), 0);
  const pendentes = lista.filter((r) => r.status === "pendente").length;

  return (
    <main className="mx-auto max-w-6xl px-5 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Painel do locador</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Seus itens anunciados e as solicitações que você recebeu.
          </p>
        </div>
        <Link
          to="/anunciar"
          className="rounded-2xl bg-brand px-5 py-3 text-sm font-medium text-primary-foreground shadow-brand"
        >
          Anunciar item
        </Link>
      </div>

      <section className="mt-6 grid gap-4 sm:grid-cols-3">
        <div className="glass rounded-2xl p-4">
          <p className="font-mono text-xs text-muted-foreground">itens anunciados</p>
          <p className="mt-1 text-2xl font-semibold">{(itens.data ?? []).length}</p>
        </div>
        <div className="glass rounded-2xl p-4">
          <p className="font-mono text-xs text-muted-foreground">solicitações pendentes</p>
          <p className="mt-1 text-2xl font-semibold">{pendentes}</p>
        </div>
        <div className="glass rounded-2xl p-4">
          <p className="font-mono text-xs text-muted-foreground">ganhos confirmados</p>
          <p className="mt-1 text-2xl font-semibold">{moeda(ganhos)}</p>
        </div>
      </section>

      <section className="mt-10">
        <h2 className="mb-4 text-xl font-semibold tracking-tight">Reservas recebidas</h2>
        {reservas.isLoading ? (
          <p className="text-sm text-muted-foreground">Carregando…</p>
        ) : lista.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            Nenhuma solicitação até agora. Anuncie mais itens para aparecer nas buscas.
          </p>
        ) : (
          <div className="space-y-3">
            {lista.map((r) => (
              <article key={r.id} className="glass-strong rounded-2xl p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="font-medium">{r.itens?.titulo ?? "Item removido"}</p>
                    <p className="mt-1 font-mono text-xs text-muted-foreground">
                      {new Date(r.data_inicio).toLocaleDateString("pt-BR")} —{" "}
                      {new Date(r.data_fim).toLocaleDateString("pt-BR")} ·{" "}
                      {moeda(Number(r.valor_total))}
                    </p>
                    {r.locatario ? (
                      <Link
                        to="/perfil/$userId"
                        params={{ userId: r.locatario.id }}
                        className="mt-1 inline-block text-xs underline decoration-dotted"
                      >
                        {r.locatario.nome}
                      </Link>
                    ) : null}
                  </div>
                  <div className="text-right">
                    <span className="rounded-full bg-secondary px-3 py-1 font-mono text-xs">
                      {statusLabel[r.status] ?? r.status}
                    </span>
                    <p className="mt-2 font-mono text-xs text-muted-foreground">
                      {pagStatus(r.id) === "pago"
                        ? "pago"
                        : pagStatus(r.id) === "reembolsado"
                          ? "reembolsado"
                          : "aguardando pagamento"}
                    </p>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  {(proximoStatus[r.status] ?? [])
                    .filter((a) => !(a.status === "em_andamento" && pagStatus(r.id) !== "pago"))
                    .map((acao) => (
                      <button
                        key={acao.status}
                        disabled={atualizarStatus.isPending}
                        onClick={() => atualizarStatus.mutate({ id: r.id, status: acao.status })}
                        className="rounded-xl border border-border px-3 py-2 text-xs font-medium hover:bg-secondary disabled:opacity-60"
                      >
                        {acao.label}
                      </button>
                    ))}
                  {r.status === "aprovada" && pagStatus(r.id) === "pago" ? (
                    <button
                      disabled={reembolsar.isPending}
                      onClick={() => {
                        if (confirm("Cancelar e reembolsar o locatário?")) reembolsar.mutate(r.id);
                      }}
                      className="rounded-xl border border-border px-3 py-2 text-xs font-medium text-destructive hover:bg-secondary disabled:opacity-60"
                    >
                      Cancelar e reembolsar
                    </button>
                  ) : null}
                </div>

                {["devolvido", "concluida"].includes(r.status) &&
                r.locatario &&
                !avaliadas.has(r.id) ? (
                  <FormAvaliacao
                    titulo="Avaliar o locatário"
                    pendente={avaliar.isPending}
                    onEnviar={(nota, comentario) =>
                      avaliar.mutate({
                        reservaId: r.id,
                        avaliadoId: r.locatario!.id,
                        nota,
                        comentario,
                      })
                    }
                  />
                ) : null}
                {avaliadas.has(r.id) ? (
                  <p className="mt-3 font-mono text-xs text-muted-foreground">locatário avaliado</p>
                ) : null}
              </article>
            ))}
          </div>
        )}
      </section>

      <section className="mt-10">
        <h2 className="mb-4 text-xl font-semibold tracking-tight">Meus itens</h2>
        {(itens.data ?? []).length === 0 ? (
          <p className="text-sm text-muted-foreground">Você ainda não anunciou nenhum item.</p>
        ) : (
          <div className="space-y-3">
            {(itens.data ?? []).map((i) => (
              <article
                key={i.id}
                className="glass flex flex-wrap items-center justify-between gap-3 rounded-2xl p-4"
              >
                <div>
                  <Link
                    to="/item/$itemId"
                    params={{ itemId: i.id }}
                    className="font-medium underline decoration-dotted"
                  >
                    {i.titulo}
                  </Link>
                  <p className="mt-1 font-mono text-xs text-muted-foreground">
                    {moeda(Number(i.preco_dia))} / dia · {i.cidade}
                    {i.ativo ? "" : " · pausado"}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Link
                    to="/anunciar"
                    search={{ editar: i.id }}
                    className="rounded-xl border border-border px-3 py-2 text-xs font-medium hover:bg-secondary"
                  >
                    Editar e agenda
                  </Link>
                  <button
                    onClick={() => alternarAtivo.mutate({ id: i.id, ativo: !i.ativo })}
                    className="rounded-xl border border-border px-3 py-2 text-xs font-medium hover:bg-secondary"
                  >
                    {i.ativo ? "Pausar" : "Reativar"}
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Excluir "${i.titulo}"?`)) excluirItem.mutate(i.id);
                    }}
                    className="rounded-xl border border-border px-3 py-2 text-xs font-medium text-destructive hover:bg-secondary"
                  >
                    Excluir
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
