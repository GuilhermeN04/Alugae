import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { nomePapel, usePapeis, type Papel } from "@/hooks/use-papeis";
import { listarAvaliacoesRecebidas, listarMeusItens, obterPerfil } from "@/lib/alugae";

export const Route = createFileRoute("/_authenticated/conta")({
  head: () => ({
    meta: [
      { title: "Minha conta — Alugaê" },
      { name: "description", content: "Edite seu perfil, veja o status da conta e altere sua senha no Alugaê." },
      { property: "og:title", content: "Minha conta — Alugaê" },
      { property: "og:description", content: "Perfil e status da conta no Alugaê." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Conta,
});

function Conta() {
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const { tem, papeis, alternar } = usePapeis();
  const perfil = useQuery({ queryKey: ["perfil", user.id], queryFn: () => obterPerfil(user.id) });
  const itens = useQuery({ queryKey: ["meus-itens", user.id], queryFn: () => listarMeusItens(user.id) });
  const avaliacoes = useQuery({ queryKey: ["avaliacoes", user.id], queryFn: () => listarAvaliacoesRecebidas(user.id) });
  const reservas = useQuery({
    queryKey: ["contagem-reservas", user.id],
    queryFn: async () => {
      const { count, error } = await supabase
        .from("reservas")
        .select("id", { count: "exact", head: true })
        .or(`locatario_id.eq.${user.id},locador_id.eq.${user.id}`);
      if (error) throw error;
      return count ?? 0;
    },
  });

  const [form, setForm] = useState({ nome: "", telefone: "", cidade: "", bairro: "", bio: "", avatar_url: "" });
  const [ok, setOk] = useState<string | null>(null);
  useEffect(() => {
    if (perfil.data)
      setForm({
        nome: perfil.data.nome ?? "",
        telefone: perfil.data.telefone ?? "",
        cidade: perfil.data.cidade ?? "",
        bairro: perfil.data.bairro ?? "",
        bio: perfil.data.bio ?? "",
        avatar_url: perfil.data.avatar_url ?? "",
      });
  }, [perfil.data]);

  const salvar = useMutation({
    mutationFn: async () => {
      const payload = Object.fromEntries(
        Object.entries(form).map(([k, v]) => [k, v.trim() || null]),
      ) as Record<string, string | null>;
      const { error } = await supabase
        .from("profiles")
        .update({ ...payload, nome: form.nome.trim() || "Usuário" })
        .eq("id", user.id);
      if (error) throw error;
    },
    onSuccess: () => {
      setOk("Perfil atualizado.");
      qc.invalidateQueries({ queryKey: ["perfil", user.id] });
    },
  });

  const [novaSenha, setNovaSenha] = useState("");
  const [msgSenha, setMsgSenha] = useState<string | null>(null);
  async function trocarSenha(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.auth.updateUser({ password: novaSenha });
    setMsgSenha(error ? "Não foi possível alterar a senha." : "Senha alterada.");
    if (!error) setNovaSenha("");
  }

  const notas = (avaliacoes.data ?? []).map((a) => a.nota);
  const media = notas.length ? (notas.reduce((a, b) => a + b, 0) / notas.length).toFixed(1) : "—";
  const completo = !!(form.nome && form.telefone && form.cidade);
  const campo = (k: keyof typeof form, label: string, ph = "") => (
    <label className="block text-xs text-muted-foreground">
      {label}
      <input value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} className="field mt-1" placeholder={ph} />
    </label>
  );

  return (
    <main className="mx-auto max-w-4xl px-5 py-10">
      <h1 className="text-3xl font-semibold tracking-tight">Minha conta</h1>

      <section className="glass-strong mt-6 rounded-3xl p-6">
        <h2 className="text-lg font-semibold">Status da conta</h2>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <Info rotulo="Situação" valor="Ativa" />
          <Info rotulo="E-mail" valor={user.email ?? "—"} />
          <Info rotulo="Membro desde" valor={new Date(user.created_at).toLocaleDateString("pt-BR")} />
          <Info rotulo="Perfil" valor={completo ? "Completo" : "Incompleto"} />
          <Info rotulo="Itens anunciados" valor={String(itens.data?.length ?? 0)} />
          <Info rotulo="Reservas" valor={String(reservas.data ?? 0)} />
          <Info rotulo="Reputação" valor={`${media} / 5 (${notas.length})`} />
        </div>
        {!completo ? (
          <p className="mt-3 text-sm text-brand-wood">Complete nome, telefone e cidade para passar mais confiança.</p>
        ) : null}
        <Link to="/perfil/$userId" params={{ userId: user.id }} className="mt-4 inline-block text-sm text-brand-wood underline-offset-4 hover:underline">
          Ver meu perfil público
        </Link>
      </section>

      <section className="glass-strong mt-6 rounded-3xl p-6">
        <h2 className="text-lg font-semibold">Meus perfis de uso</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Locador anuncia itens e recebe reservas. Locatário aluga itens. Você pode ter os dois.
        </p>
        <div className="mt-4 flex flex-wrap gap-3">
          {(["locador", "locatario"] as Papel[]).map((p) => (
            <button
              key={p}
              disabled={alternar.isPending || (tem(p) && papeis.length === 1)}
              onClick={() => alternar.mutate({ papel: p, ativo: !tem(p) })}
              className={`rounded-2xl border px-4 py-2 text-sm font-medium disabled:opacity-60 ${tem(p) ? "border-brand bg-brand/15" : "border-border"}`}
            >
              {nomePapel[p]}: {tem(p) ? "ativo" : "inativo"}
            </button>
          ))}
        </div>
      </section>

      <section className="glass-strong mt-6 rounded-3xl p-6">
        <h2 className="text-lg font-semibold">Editar perfil</h2>
        <form
          onSubmit={(e) => { e.preventDefault(); setOk(null); salvar.mutate(); }}
          className="mt-4 grid gap-3 sm:grid-cols-2"
        >
          {campo("nome", "Nome")}
          {campo("telefone", "Telefone", "(85) 90000-0000")}
          {campo("cidade", "Cidade", "Fortaleza")}
          {campo("bairro", "Bairro")}
          <div className="sm:col-span-2">{campo("avatar_url", "Foto (link da imagem)", "https://…")}</div>
          <label className="block text-xs text-muted-foreground sm:col-span-2">
            Sobre você
            <textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} rows={3} className="field mt-1" />
          </label>
          <div className="flex items-center gap-3 sm:col-span-2">
            <button type="submit" disabled={salvar.isPending} className="rounded-2xl bg-brand px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-brand disabled:opacity-60">
              {salvar.isPending ? "Salvando…" : "Salvar perfil"}
            </button>
            {ok ? <span className="text-sm text-brand-wood">{ok}</span> : null}
            {salvar.error ? <span className="text-sm text-destructive">Erro ao salvar.</span> : null}
          </div>
        </form>
      </section>

      <section className="glass-strong mt-6 rounded-3xl p-6">
        <h2 className="text-lg font-semibold">Alterar senha</h2>
        <form onSubmit={trocarSenha} className="mt-4 flex flex-wrap items-end gap-3">
          <label className="block flex-1 text-xs text-muted-foreground">
            Nova senha
            <input required type="password" minLength={6} value={novaSenha} onChange={(e) => setNovaSenha(e.target.value)} className="field mt-1" />
          </label>
          <button type="submit" className="rounded-2xl bg-ink px-5 py-2.5 text-sm font-medium text-cream">Alterar</button>
        </form>
        {msgSenha ? <p className="mt-2 text-sm text-brand-wood">{msgSenha}</p> : null}
      </section>
    </main>
  );
}

function Info({ rotulo, valor }: { rotulo: string; valor: string }) {
  return (
    <div className="glass rounded-2xl p-3">
      <p className="font-mono text-[11px] uppercase text-muted-foreground">{rotulo}</p>
      <p className="mt-1 truncate text-sm font-medium">{valor}</p>
    </div>
  );
}
