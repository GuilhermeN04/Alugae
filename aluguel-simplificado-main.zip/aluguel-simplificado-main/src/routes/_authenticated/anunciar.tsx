import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { listarCategorias } from "@/lib/alugae";

export const Route = createFileRoute("/_authenticated/anunciar")({
  head: () => ({
    meta: [
      { title: "Anunciar um item — Alugaê" },
      {
        name: "description",
        content: "Cadastre seu item com foto, categoria, preço por dia, condições e localização.",
      },
      { property: "og:title", content: "Anunciar um item — Alugaê" },
      { property: "og:description", content: "Coloque seu item para alugar no Alugaê." },
    ],
  }),
  component: Anunciar,
});

function Anunciar() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const categorias = useQuery({ queryKey: ["categorias"], queryFn: listarCategorias });

  const [form, setForm] = useState({
    titulo: "",
    descricao: "",
    condicoes_uso: "",
    preco_dia: "",
    cidade: "Fortaleza",
    bairro: "",
    imagem_url: "",
    categoria_id: "",
  });
  const [erro, setErro] = useState<string | null>(null);

  const salvar = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Sessão expirada.");
      const preco = Number(form.preco_dia.replace(",", "."));
      if (!form.titulo.trim()) throw new Error("Informe o nome do item.");
      if (!Number.isFinite(preco) || preco <= 0) throw new Error("Informe um preço por dia válido.");
      const { data, error } = await supabase
        .from("itens")
        .insert({
          locador_id: user.id,
          titulo: form.titulo.trim(),
          descricao: form.descricao.trim(),
          condicoes_uso: form.condicoes_uso.trim() || null,
          preco_dia: preco,
          cidade: form.cidade.trim() || "Fortaleza",
          bairro: form.bairro.trim() || null,
          imagem_url: form.imagem_url.trim() || null,
          categoria_id: form.categoria_id || null,
        })
        .select("id")
        .single();
      if (error) throw error;
      return data.id;
    },
    onSuccess: () => navigate({ to: "/painel" }),
    onError: (e) => setErro(e instanceof Error ? e.message : "Não foi possível salvar."),
  });

  const campo = (k: keyof typeof form) => ({
    value: form[k],
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [k]: e.target.value })),
  });

  return (
    <main className="mx-auto max-w-2xl px-5 py-10">
      <h1 className="text-2xl font-semibold tracking-tight">Anunciar um item</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Quanto mais detalhes, mais confiança para quem vai alugar.
      </p>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          setErro(null);
          salvar.mutate();
        }}
        className="glass-strong mt-6 space-y-3 rounded-3xl p-5"
      >
        <label className="block text-xs text-muted-foreground">
          Nome do item
          <input required className="field mt-1" placeholder="Furadeira de impacto" {...campo("titulo")} />
        </label>
        <label className="block text-xs text-muted-foreground">
          Descrição
          <textarea
            rows={3}
            className="field mt-1"
            placeholder="O que acompanha, estado de conservação…"
            {...campo("descricao")}
          />
        </label>
        <label className="block text-xs text-muted-foreground">
          Condições de uso
          <input
            className="field mt-1"
            placeholder="Devolver com a bateria carregada"
            {...campo("condicoes_uso")}
          />
        </label>
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="block text-xs text-muted-foreground">
            Preço por dia (R$)
            <input required className="field mt-1" placeholder="25" {...campo("preco_dia")} />
          </label>
          <label className="block text-xs text-muted-foreground">
            Categoria
            <select className="field mt-1" {...campo("categoria_id")}>
              <option value="">Selecione</option>
              {(categorias.data ?? []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.nome}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-xs text-muted-foreground">
            Cidade
            <input className="field mt-1" {...campo("cidade")} />
          </label>
          <label className="block text-xs text-muted-foreground">
            Bairro
            <input className="field mt-1" placeholder="Meireles" {...campo("bairro")} />
          </label>
        </div>
        <label className="block text-xs text-muted-foreground">
          Link da foto
          <input className="field mt-1" placeholder="https://…" {...campo("imagem_url")} />
        </label>

        {erro ? <p className="text-sm text-destructive">{erro}</p> : null}

        <button
          type="submit"
          disabled={salvar.isPending}
          className="w-full rounded-2xl bg-brand py-3 text-sm font-medium text-primary-foreground shadow-brand disabled:opacity-60"
        >
          {salvar.isPending ? "Publicando…" : "Publicar item"}
        </button>
      </form>
    </main>
  );
}
