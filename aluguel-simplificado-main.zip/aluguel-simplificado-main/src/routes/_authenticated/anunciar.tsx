import { ExigePapel } from "@/hooks/use-papeis";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { enviarFotoItem, listarCategorias, listarFotos, obterItem, periodosBloqueados, periodosOcupados, salvarFotos } from "@/lib/alugae";
import { CalendarioDisponibilidade } from "@/components/calendario-disponibilidade";

export const Route = createFileRoute("/_authenticated/anunciar")({
  head: () => ({
    meta: [
      { title: "Anunciar um item — Alugaê" },
      {
        name: "description",
        content: "Cadastre seu item com foto, categoria, preço por dia, condições e localização.",
      },
      { property: "og:title", content: "Anunciar um item — Alugaê" },
      { property: "og:description", content: "Coloque seu item para alugar no Alugaê." },
    ],
  }),
  validateSearch: (s: Record<string, unknown>): { editar?: string } =>
    typeof s["editar"] === "string" ? { editar: s["editar"] } : {},
  component: () => (
    <ExigePapel papel="locador">
      <Anunciar />
    </ExigePapel>
  ),
});

function Anunciar() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { editar } = Route.useSearch();
  const categorias = useQuery({ queryKey: ["categorias"], queryFn: listarCategorias });
  const existente = useQuery({
    queryKey: ["item", editar],
    queryFn: () => obterItem(editar!),
    enabled: !!editar,
  });
  const reservados = useQuery({
    queryKey: ["ocupados", editar],
    queryFn: () => periodosOcupados(editar!),
    enabled: !!editar,
  });
  const bloqueados = useQuery({
    queryKey: ["bloqueados", editar],
    queryFn: () => periodosBloqueados(editar!),
    enabled: !!editar,
  });
  const alternarDia = useMutation({
    mutationFn: async (dia: string) => {
      const cobrindo = (bloqueados.data ?? []).filter((b) => dia >= b.data_inicio && dia <= b.data_fim);
      if (cobrindo.length) {
        const { error } = await supabase.from("disponibilidades").delete().in("id", cobrindo.map((b) => b.id));
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("disponibilidades")
          .insert({ item_id: editar!, data_inicio: dia, data_fim: dia, bloqueado: true });
        if (error) throw error;
      }
    },
    onSuccess: () => bloqueados.refetch(),
  });
  const [bloqIni, setBloqIni] = useState("");
  const [bloqFim, setBloqFim] = useState("");
  const [enviando, setEnviando] = useState(false);
  const bloquearPeriodo = useMutation({
    mutationFn: async () => {
      const conflito = (reservados.data ?? []).some((r) => bloqIni <= r.data_fim && r.data_inicio <= bloqFim);
      if (conflito) throw new Error("Esse período tem reservas ativas.");
      const { error } = await supabase
        .from("disponibilidades")
        .insert({ item_id: editar!, data_inicio: bloqIni, data_fim: bloqFim, bloqueado: true });
      if (error) throw error;
    },
    onSuccess: () => {
      setBloqIni("");
      setBloqFim("");
      bloqueados.refetch();
    },
    onError: (e) => setErro(e instanceof Error ? e.message : "Não foi possível bloquear."),
  });
  const desbloquear = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("disponibilidades").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => bloqueados.refetch(),
  });

  const [form, setForm] = useState({
    titulo: "",
    descricao: "",
    condicoes_uso: "",
    preco_dia: "",
    cidade: "Fortaleza",
    bairro: "",
    imagem_url: "",
    categoria_id: "",
  });
  const [erro, setErro] = useState<string | null>(null);

  const [fotos, setFotos] = useState<string[]>([]);
  const fotosExistentes = useQuery({
    queryKey: ["fotos", editar],
    queryFn: () => listarFotos(editar!, existente.data?.imagem_url),
    enabled: !!editar && existente.isSuccess,
  });
  useEffect(() => {
    if (fotosExistentes.data) setFotos(fotosExistentes.data);
  }, [fotosExistentes.data]);

  useEffect(() => {
    const i = existente.data;
    if (!i) return;
    setForm({
      titulo: i.titulo,
      descricao: i.descricao ?? "",
      condicoes_uso: i.condicoes_uso ?? "",
      preco_dia: String(i.preco_dia),
      cidade: i.cidade,
      bairro: i.bairro ?? "",
      imagem_url: i.imagem_url ?? "",
      categoria_id: i.categoria_id ?? "",
    });
  }, [existente.data]);

  const salvar = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Sessão expirada.");
      const preco = Number(form.preco_dia.replace(",", "."));
      if (!form.titulo.trim()) throw new Error("Informe o nome do item.");
      if (!Number.isFinite(preco) || preco <= 0) throw new Error("Informe um preço por dia válido.");
      const campos = {
          titulo: form.titulo.trim(),
          descricao: form.descricao.trim(),
          condicoes_uso: form.condicoes_uso.trim() || null,
          preco_dia: preco,
          cidade: form.cidade.trim() || "Fortaleza",
          bairro: form.bairro.trim() || null,
          imagem_url: fotos[0] ?? null,
          categoria_id: form.categoria_id || null,
      };
      if (editar) {
        const { error } = await supabase.from("itens").update(campos).eq("id", editar);
        if (error) throw error;
        await salvarFotos(editar, fotos);
        return editar;
      }
      const { data, error } = await supabase
        .from("itens")
        .insert({ ...campos, locador_id: user.id })
        .select("id")
        .single();
      if (error) throw error;
      await salvarFotos(data.id, fotos);
      return data.id;
    },
    onSuccess: () => navigate({ to: "/painel" }),
    onError: (e) => setErro(e instanceof Error ? e.message : "Não foi possível salvar."),
  });

  const campo = (k: keyof typeof form) => ({
    value: form[k],
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [k]: e.target.value })),
  });

  return (
    <main className="mx-auto max-w-2xl px-5 py-10">
      <h1 className="text-2xl font-semibold tracking-tight">{editar ? "Editar item" : "Anunciar um item"}</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Quanto mais detalhes, mais confiança para quem vai alugar.
      </p>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          setErro(null);
          salvar.mutate();
        }}
        className="glass-strong mt-6 space-y-3 rounded-3xl p-5"
      >
        <label className="block text-xs text-muted-foreground">
          Nome do item
          <input required className="field mt-1" placeholder="Furadeira de impacto" {...campo("titulo")} />
        </label>
        <label className="block text-xs text-muted-foreground">
          Descrição
          <textarea
            rows={3}
            className="field mt-1"
            placeholder="O que acompanha, estado de conservação…"
            {...campo("descricao")}
          />
        </label>
        <label className="block text-xs text-muted-foreground">
          Condições de uso
          <input
            className="field mt-1"
            placeholder="Devolver com a bateria carregada"
            {...campo("condicoes_uso")}
          />
        </label>
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="block text-xs text-muted-foreground">
            Preço por dia (R$)
            <input required className="field mt-1" placeholder="25" {...campo("preco_dia")} />
          </label>
          <label className="block text-xs text-muted-foreground">
            Categoria
            <select className="field mt-1" {...campo("categoria_id")}>
              <option value="">Selecione</option>
              {(categorias.data ?? []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.nome}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-xs text-muted-foreground">
            Cidade
            <input className="field mt-1" {...campo("cidade")} />
          </label>
          <label className="block text-xs text-muted-foreground">
            Bairro
            <input className="field mt-1" placeholder="Meireles" {...campo("bairro")} />
          </label>
        </div>
        <div className="block text-xs text-muted-foreground">
          Foto do item
          <div className="mt-1 flex items-center gap-3">
            {form.imagem_url ? (
              <img src={form.imagem_url} alt="Foto do item" className="size-20 rounded-xl object-cover ring-1 ring-border" />
            ) : null}
            <label className="cursor-pointer rounded-xl bg-background/70 px-4 py-2 text-sm text-foreground ring-1 ring-border hover:bg-secondary">
              {enviando ? "Enviando…" : form.imagem_url ? "Trocar foto" : "Enviar foto"}
              <input
                type="file"
                accept="image/*"
                className="hidden"
                disabled={enviando}
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  e.target.value = "";
                  if (!f || !user) return;
                  setErro(null);
                  setEnviando(true);
                  try {
                    const url = await enviarFotoItem(user.id, f);
                    setForm((s) => ({ ...s, imagem_url: url }));
                  } catch (err) {
                    setErro(err instanceof Error ? err.message : "Falha ao enviar a foto.");
                  } finally {
                    setEnviando(false);
                  }
                }}
              />
            </label>
          </div>
        </div>

        {erro ? <p className="text-sm text-destructive">{erro}</p> : null}

        <button
          type="submit"
          disabled={salvar.isPending}
          className="w-full rounded-2xl bg-brand py-3 text-sm font-medium text-primary-foreground shadow-brand disabled:opacity-60"
        >
          {salvar.isPending ? "Salvando…" : editar ? "Salvar alterações" : "Publicar item"}
        </button>
      </form>

      {editar ? (
        <section className="glass-strong mt-6 rounded-3xl p-5">
          <h2 className="text-lg font-semibold tracking-tight">Calendário de disponibilidade</h2>
          <p className="mb-3 mt-1 text-sm text-muted-foreground">
            Toque num dia para marcar ou desmarcar como indisponível, ou bloqueie um período inteiro.
          </p>
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <label className="text-xs text-muted-foreground">
              De
              <input type="date" className="field mt-1" value={bloqIni} onChange={(e) => setBloqIni(e.target.value)} />
            </label>
            <label className="text-xs text-muted-foreground">
              Até
              <input type="date" className="field mt-1" value={bloqFim} onChange={(e) => setBloqFim(e.target.value)} />
            </label>
            <button
              type="button"
              disabled={!bloqIni || !bloqFim || bloqFim < bloqIni || bloquearPeriodo.isPending}
              onClick={() => bloquearPeriodo.mutate()}
              className="rounded-xl bg-ink px-4 py-2.5 text-sm font-medium text-cream disabled:opacity-50"
            >
              Bloquear período
            </button>
          </div>
          <CalendarioDisponibilidade
            reservados={reservados.data ?? []}
            bloqueados={bloqueados.data ?? []}
            onAlternar={(d) => !alternarDia.isPending && alternarDia.mutate(d)}
          />
          {(bloqueados.data ?? []).length ? (
            <ul className="mt-3 space-y-1 text-xs">
              {(bloqueados.data ?? []).map((b) => (
                <li key={b.id} className="flex items-center justify-between rounded-lg bg-background/60 px-3 py-1.5 ring-1 ring-border">
                  <span>
                    {new Date(b.data_inicio + "T12:00").toLocaleDateString("pt-BR")} –{" "}
                    {new Date(b.data_fim + "T12:00").toLocaleDateString("pt-BR")}
                  </span>
                  <button type="button" className="text-destructive" onClick={() => desbloquear.mutate(b.id)}>
                    Liberar
                  </button>
                </li>
              ))}
            </ul>
          ) : null}
        </section>
      ) : null}
    </main>
  );
}
