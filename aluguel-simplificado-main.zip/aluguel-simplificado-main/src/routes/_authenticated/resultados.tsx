import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { listarReservasComoLocador, listarReservasComoLocatario, moeda, statusLabel, type ReservaCompleta } from "@/lib/alugae";

export const Route = createFileRoute("/_authenticated/resultados")({
  head: () => ({
    meta: [
      { title: "Resultados das aprovações — Alugaê" },
      { name: "description", content: "Veja quais pedidos de aluguel foram aprovados, recusados ou aguardam resposta." },
      { property: "og:title", content: "Resultados das aprovações — Alugaê" },
      { property: "og:description", content: "Acompanhe o resultado de cada pedido de aluguel." },
    ],
  }),
  component: Resultados,
});

const grupos = [
  { titulo: "Aguardando resposta", status: ["pendente"], cor: "text-brand-wood" },
  { titulo: "Aprovados", status: ["aprovada", "em_andamento", "devolvido", "concluida"], cor: "text-foreground" },
  { titulo: "Recusados", status: ["recusada"], cor: "text-destructive" },
  { titulo: "Cancelados", status: ["cancelada"], cor: "text-muted-foreground" },
];

const dataBr = (d: string) => new Date(d + "T12:00").toLocaleDateString("pt-BR");

function Lista({ titulo, reservas, papel }: { titulo: string; reservas: ReservaCompleta[]; papel: "feitos" | "recebidos" }) {
  return (
    <section className="mt-8">
      <h2 className="text-lg font-semibold tracking-tight">{titulo}</h2>
      <div className="mt-3 grid gap-3 sm:grid-cols-4">
        {grupos.map((g) => {
          const n = reservas.filter((r) => g.status.includes(r.status)).length;
          return (
            <div key={g.titulo} className="glass rounded-2xl p-4">
              <p className="font-mono text-[11px] uppercase tracking-[0.15em] text-muted-foreground">{g.titulo}</p>
              <p className={`mt-1 text-2xl font-semibold ${g.cor}`}>{n}</p>
            </div>
          );
        })}
      </div>
      {grupos.map((g) => {
        const lista = reservas.filter((r) => g.status.includes(r.status));
        if (!lista.length) return null;
        return (
          <div key={g.titulo} className="mt-5">
            <p className={`font-mono text-xs uppercase tracking-[0.15em] ${g.cor}`}>{g.titulo}</p>
            <ul className="mt-2 space-y-2">
              {lista.map((r) => (
                <li key={r.id} className="glass-strong flex flex-wrap items-center justify-between gap-2 rounded-2xl p-4 text-sm">
                  <div>
                    <Link to="/item/$itemId" params={{ itemId: r.item_id }} className="font-medium hover:underline">
                      {r.itens?.titulo ?? "Item"}
                    </Link>
                    <p className="text-xs text-muted-foreground">
                      {dataBr(r.data_inicio)} – {dataBr(r.data_fim)} ·{" "}
                      {papel === "feitos" ? `Dono: ${r.locador?.nome ?? "—"}` : `Pedido por: ${r.locatario?.nome ?? "—"}`}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">{moeda(Number(r.valor_total))}</p>
                    <p className={`text-xs ${g.cor}`}>{statusLabel[r.status] ?? r.status}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        );
      })}
      {!reservas.length ? <p className="mt-3 text-sm text-muted-foreground">Nenhum pedido ainda.</p> : null}
    </section>
  );
}

function Resultados() {
  const { user } = useAuth();
  const feitos = useQuery({
    queryKey: ["reservas-locatario", user?.id],
    queryFn: () => listarReservasComoLocatario(user!.id),
    enabled: !!user,
  });
  const recebidos = useQuery({
    queryKey: ["reservas-locador", user?.id],
    queryFn: () => listarReservasComoLocador(user!.id),
    enabled: !!user,
  });
  return (
    <main className="mx-auto max-w-4xl px-5 py-10">
      <h1 className="text-2xl font-semibold tracking-tight">Resultados das aprovações</h1>
      <p className="mt-1 text-sm text-muted-foreground">O resultado de cada pedido de aluguel, feito ou recebido.</p>
      <Lista titulo="Pedidos que fiz" reservas={feitos.data ?? []} papel="feitos" />
      <Lista titulo="Pedidos que recebi" reservas={recebidos.data ?? []} papel="recebidos" />
    </main>
  );
}
