import { ExigePapel } from "@/hooks/use-papeis";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { listarReservasComoLocatario, moeda, statusLabel } from "@/lib/alugae";
import { FormAvaliacao } from "@/components/form-avaliacao";

export const Route = createFileRoute("/_authenticated/reservas")({
  head: () => ({
    meta: [
      { title: "Minhas reservas — Alugaê" },
      {
        name: "description",
        content:
          "Acompanhe seus aluguéis, pague com Pix e avalie quem alugou o item para você no Alugaê.",
      },
      { property: "og:title", content: "Minhas reservas — Alugaê" },
      { property: "og:description", content: "Seus aluguéis, pagamentos e avaliações no Alugaê." },
    ],
  }),
  component: () => (
    <ExigePapel papel="locatario">
      <MinhasReservas />
    </ExigePapel>
  ),
});

function MinhasReservas() {
  const { user } = useAuth();
  const userId = user?.id ?? "";
  const qc = useQueryClient();

  const reservas = useQuery({
    queryKey: ["reservas-locatario", userId],
    queryFn: () => listarReservasComoLocatario(userId),
    enabled: !!userId,
  });

  const pagamentos = useQuery({
    queryKey: ["meus-pagamentos", userId],
    queryFn: async () => {
      const { data, error } = await supabase.from("pagamentos").select("*");
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!userId,
  });

  const avaliacoes = useQuery({
    queryKey: ["minhas-avaliacoes", userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("avaliacoes")
        .select("id, reserva_id")
        .eq("autor_id", userId);
      if (error) throw error;
      return data ?? [];
    },
    enabled: !!userId,
  });

  const [erro, setErro] = useState<string | null>(null);

  const pagar = useMutation({
    mutationFn: async ({ reservaId, valor }: { reservaId: string; valor: number }) => {
      const { error } = await supabase.from("pagamentos").upsert(
        {
          reserva_id: reservaId,
          valor,
          metodo: "pix",
          status: "pago" as const,
          pago_em: new Date().toISOString(),
        },
        { onConflict: "reserva_id" },
      );
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["meus-pagamentos", userId] }),
    onError: (e) => setErro(e instanceof Error ? e.message : "Não foi possível registrar o pagamento."),
  });

  const cancelar = useMutation({
    mutationFn: async ({ id, pago }: { id: string; pago: boolean }) => {
      const { error } = await supabase.from("reservas").update({ status: "cancelada" }).eq("id", id);
      if (error) throw error;
      if (pago) {
        const { error: e2 } = await supabase
          .from("pagamentos")
          .update({ status: "reembolsado" })
          .eq("reserva_id", id);
        if (e2) throw e2;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["reservas-locatario", userId] });
      qc.invalidateQueries({ queryKey: ["meus-pagamentos", userId] });
    },
    onError: (e) => setErro(e instanceof Error ? e.message : "Não foi possível cancelar."),
  });

  const devolver = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("reservas").update({ status: "devolvido" }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["reservas-locatario", userId] }),
    onError: (e) => setErro(e instanceof Error ? e.message : "Não foi possível confirmar."),
  });

  const avaliar = useMutation({
    mutationFn: async (input: {
      reservaId: string;
      avaliadoId: string;
      nota: number;
      comentario: string;
    }) => {
      const { error } = await supabase.from("avaliacoes").insert({
        reserva_id: input.reservaId,
        autor_id: userId,
        avaliado_id: input.avaliadoId,
        nota: input.nota,
        comentario: input.comentario.trim() || null,
      });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["minhas-avaliacoes", userId] }),
    onError: (e) => setErro(e instanceof Error ? e.message : "Não foi possível enviar a avaliação."),
  });

  const lista = reservas.data ?? [];
  const pags = pagamentos.data ?? [];
  const totalGasto = lista
    .filter((r) => pags.some((p) => p.reserva_id === r.id && p.status === "pago"))
    .reduce((s, r) => s + Number(r.valor_total), 0);
  const ativas = lista.filter((r) => ["aprovada", "em_andamento"].includes(r.status)).length;

  return (
    <main className="mx-auto max-w-4xl px-5 py-10">
      <h1 className="text-2xl font-semibold tracking-tight">Minhas reservas</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Pague, acompanhe a devolução e avalie a experiência.
      </p>

      <section className="mt-6 grid gap-4 sm:grid-cols-3">
        <div className="glass rounded-2xl p-4">
          <p className="font-mono text-xs text-muted-foreground">reservas feitas</p>
          <p className="mt-1 text-2xl font-semibold">{lista.length}</p>
        </div>
        <div className="glass rounded-2xl p-4">
          <p className="font-mono text-xs text-muted-foreground">aluguéis ativos</p>
          <p className="mt-1 text-2xl font-semibold">{ativas}</p>
        </div>
        <div className="glass rounded-2xl p-4">
          <p className="font-mono text-xs text-muted-foreground">total pago</p>
          <p className="mt-1 text-2xl font-semibold">{moeda(totalGasto)}</p>
        </div>
      </section>

      {erro ? <p className="mt-4 text-sm text-destructive">{erro}</p> : null}

      {reservas.isLoading ? (
        <p className="mt-6 text-sm text-muted-foreground">Carregando…</p>
      ) : lista.length === 0 ? (
        <p className="mt-6 text-sm text-muted-foreground">
          Você ainda não solicitou nenhum aluguel.{" "}
          <Link to="/" className="underline decoration-dotted">
            Ver itens disponíveis
          </Link>
        </p>
      ) : (
        <div className="mt-6 space-y-4">
          {lista.map((r) => {
            const pago = pags.some((p) => p.reserva_id === r.id && p.status === "pago");
            const reembolsado = pags.some(
              (p) => p.reserva_id === r.id && p.status === "reembolsado",
            );
            const jaAvaliou = (avaliacoes.data ?? []).some((a) => a.reserva_id === r.id);
            const podeAvaliar = ["devolvido", "concluida"].includes(r.status) && !jaAvaliou;

            return (
              <article key={r.id} className="glass-strong rounded-3xl p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <Link
                      to="/item/$itemId"
                      params={{ itemId: r.item_id }}
                      className="font-medium underline decoration-dotted"
                    >
                      {r.itens?.titulo ?? "Item removido"}
                    </Link>
                    <p className="mt-1 font-mono text-xs text-muted-foreground">
                      {new Date(r.data_inicio).toLocaleDateString("pt-BR")} —{" "}
                      {new Date(r.data_fim).toLocaleDateString("pt-BR")} ·{" "}
                      {moeda(Number(r.valor_total))}
                    </p>
                    {r.locador ? (
                      <Link
                        to="/perfil/$userId"
                        params={{ userId: r.locador.id }}
                        className="mt-1 inline-block text-xs underline decoration-dotted"
                      >
                        Anunciado por {r.locador.nome}
                      </Link>
                    ) : null}
                  </div>
                  <div className="text-right">
                    <span className="rounded-full bg-secondary px-3 py-1 font-mono text-xs">
                      {statusLabel[r.status] ?? r.status}
                    </span>
                    <p className="mt-2 font-mono text-xs text-muted-foreground">
                      {reembolsado
                        ? "pagamento reembolsado"
                        : pago
                          ? "pagamento confirmado"
                          : "pagamento pendente"}
                    </p>
                  </div>
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  {r.status === "aprovada" && !pago ? (
                    <button
                      disabled={pagar.isPending}
                      onClick={() =>
                        pagar.mutate({ reservaId: r.id, valor: Number(r.valor_total) })
                      }
                      className="rounded-xl bg-brand px-4 py-2 text-xs font-medium text-primary-foreground shadow-brand disabled:opacity-60"
                    >
                      Pagar com Pix
                    </button>
                  ) : null}
                  {r.status === "em_andamento" ? (
                    <button
                      disabled={devolver.isPending}
                      onClick={() => devolver.mutate(r.id)}
                      className="rounded-xl bg-brand px-4 py-2 text-xs font-medium text-primary-foreground shadow-brand disabled:opacity-60"
                    >
                      Confirmar devolução
                    </button>
                  ) : null}
                  {["pendente", "aprovada"].includes(r.status) ? (
                    <button
                      disabled={cancelar.isPending}
                      onClick={() => {
                        const msg = pago
                          ? "Cancelar a reserva? O valor pago será reembolsado."
                          : "Cancelar a reserva?";
                        if (confirm(msg)) cancelar.mutate({ id: r.id, pago });
                      }}
                      className="rounded-xl border border-border px-4 py-2 text-xs font-medium hover:bg-secondary"
                    >
                      Cancelar reserva
                    </button>
                  ) : null}
                </div>

                {podeAvaliar && r.locador ? (
                  <FormAvaliacao
                    titulo="Avaliar o anunciante"
                    pendente={avaliar.isPending}
                    onEnviar={(nota, comentario) =>
                      avaliar.mutate({
                        reservaId: r.id,
                        avaliadoId: r.locador!.id,
                        nota,
                        comentario,
                      })
                    }
                  />
                ) : null}

                {jaAvaliou ? (
                  <p className="mt-4 font-mono text-xs text-muted-foreground">
                    avaliação enviada · obrigado
                  </p>
                ) : null}
              </article>
            );
          })}
        </div>
      )}
    </main>
  );
}
