import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/redefinir-senha")({
  head: () => ({
    meta: [
      { title: "Redefinir senha — Alugaê" },
      { name: "description", content: "Crie uma nova senha para recuperar sua conta Alugaê." },
      { property: "og:title", content: "Redefinir senha — Alugaê" },
      { property: "og:description", content: "Recuperação de conta do Alugaê." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RedefinirSenha,
});

function RedefinirSenha() {
  const navigate = useNavigate();
  const [senha, setSenha] = useState("");
  const [confirma, setConfirma] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(false);

  async function salvar(e: React.FormEvent) {
    e.preventDefault();
    setErro(null);
    if (senha !== confirma) return setErro("As senhas não conferem.");
    setCarregando(true);
    const { error } = await supabase.auth.updateUser({ password: senha });
    setCarregando(false);
    if (error) return setErro("Link inválido ou expirado. Peça um novo na tela de entrar.");
    navigate({ to: "/painel" });
  }

  return (
    <main className="mx-auto flex max-w-md flex-col px-5 py-16">
      <div className="glass-strong rounded-3xl p-6">
        <h1 className="text-2xl font-semibold tracking-tight">Criar nova senha</h1>
        <p className="mt-1 text-sm text-muted-foreground">Digite a nova senha da sua conta.</p>
        <form onSubmit={salvar} className="mt-6 space-y-3">
          <label className="block text-xs text-muted-foreground">
            Nova senha
            <input required type="password" minLength={6} value={senha} onChange={(e) => setSenha(e.target.value)} className="field mt-1" />
          </label>
          <label className="block text-xs text-muted-foreground">
            Confirmar senha
            <input required type="password" minLength={6} value={confirma} onChange={(e) => setConfirma(e.target.value)} className="field mt-1" />
          </label>
          {erro ? <p className="text-sm text-destructive">{erro}</p> : null}
          <button type="submit" disabled={carregando} className="w-full rounded-2xl bg-brand py-3 text-sm font-medium text-primary-foreground shadow-brand disabled:opacity-60">
            {carregando ? "Salvando…" : "Salvar nova senha"}
          </button>
        </form>
      </div>
    </main>
  );
}
