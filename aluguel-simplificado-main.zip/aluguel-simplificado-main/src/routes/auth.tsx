import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar no Alugaê" },
      {
        name: "description",
        content: "Acesse sua conta Alugaê para anunciar itens e acompanhar suas reservas.",
      },
      { property: "og:title", content: "Entrar no Alugaê" },
      { property: "og:description", content: "Cadastro e login da plataforma Alugaê." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [modo, setModo] = useState<"entrar" | "cadastrar" | "recuperar">("entrar");
  const [nome, setNome] = useState("");
  const [papel, setPapel] = useState<"locador" | "locatario" | "ambos">("ambos");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [mensagem, setMensagem] = useState<string | null>(null);
  const [erro, setErro] = useState<string | null>(null);
  const [carregando, setCarregando] = useState(false);

  async function enviar(e: React.FormEvent) {
    e.preventDefault();
    setErro(null);
    setMensagem(null);
    setCarregando(true);
    try {
      if (modo === "recuperar") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/redefinir-senha`,
        });
        if (error) throw error;
        setMensagem("Enviamos um link para seu e-mail. Abra-o para criar uma nova senha.");
      } else if (modo === "cadastrar") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password: senha,
          options: {
            data: { nome, papel },
            emailRedirectTo: window.location.origin,
          },
        });
        if (error) throw error;
        if (!data.session) {
          const { error: e2 } = await supabase.auth.signInWithPassword({ email, password: senha });
          if (e2) throw e2;
        }
        navigate({ to: papel === "locatario" ? "/reservas" : "/painel" });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password: senha });
        if (error) throw error;
        navigate({ to: "/painel" });
      }
    } catch (e) {
      setErro(e instanceof Error ? e.message : "Não foi possível continuar.");
    } finally {
      setCarregando(false);
    }
  }

  return (
    <main className="mx-auto flex max-w-md flex-col px-5 py-16">
      <div className="glass-strong rounded-3xl p-6">
        <h1 className="text-2xl font-semibold tracking-tight">
          {modo === "entrar" ? "Entrar no Alugaê" : modo === "cadastrar" ? "Criar conta no Alugaê" : "Recuperar conta"}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {modo === "recuperar"
            ? "Informe seu e-mail e enviaremos um link para redefinir a senha."
            : "Escolha seu perfil: locador (anuncia) e/ou locatário (aluga)."}
        </p>

        <form onSubmit={enviar} className="mt-6 space-y-3">
          {modo === "cadastrar" ? (
            <label className="block text-xs text-muted-foreground">
              Nome
              <input
                required
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                className="field mt-1"
                placeholder="Seu nome"
              />
            </label>
          ) : null}
          {modo === "cadastrar" ? (
            <fieldset className="text-xs text-muted-foreground">
              <legend>Como você vai usar o Alugaê?</legend>
              <div className="mt-1 grid grid-cols-3 gap-2">
                {([
                  ["locatario", "Quero alugar"],
                  ["locador", "Quero anunciar"],
                  ["ambos", "Os dois"],
                ] as const).map(([v, l]) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setPapel(v)}
                    className={`rounded-xl border px-2 py-2 text-xs font-medium ${papel === v ? "border-brand bg-brand/15 text-foreground" : "border-border"}`}
                  >
                    {l}
                  </button>
                ))}
              </div>
            </fieldset>
          ) : null}
          <label className="block text-xs text-muted-foreground">
            E-mail
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="field mt-1"
              placeholder="voce@email.com"
            />
          </label>
          {modo !== "recuperar" ? (
            <label className="block text-xs text-muted-foreground">
              Senha
              <input
                required
                type="password"
                minLength={6}
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                className="field mt-1"
                placeholder="mínimo 6 caracteres"
              />
            </label>
          ) : null}

          {erro ? <p className="text-sm text-destructive">{erro}</p> : null}
          {mensagem ? <p className="text-sm text-brand-wood">{mensagem}</p> : null}

          <button
            type="submit"
            disabled={carregando}
            className="w-full rounded-2xl bg-brand py-3 text-sm font-medium text-primary-foreground shadow-brand disabled:opacity-60"
          >
            {carregando
              ? "Enviando…"
              : modo === "entrar"
                ? "Entrar"
                : modo === "cadastrar"
                  ? "Criar conta"
                  : "Enviar link de recuperação"}
          </button>
        </form>

        {modo === "entrar" ? (
          <button
            onClick={() => { setModo("recuperar"); setErro(null); setMensagem(null); }}
            className="mt-4 w-full text-sm text-muted-foreground underline-offset-4 hover:underline"
          >
            Esqueci minha senha
          </button>
        ) : null}
        <button
          onClick={() => { setModo(modo === "entrar" ? "cadastrar" : "entrar"); setErro(null); setMensagem(null); }}
          className="mt-2 w-full text-sm text-brand-wood underline-offset-4 hover:underline"
        >
          {modo === "entrar" ? "Não tem conta? Cadastre-se" : "Já tem conta? Entrar"}
        </button>
      </div>
    </main>
  );
}
