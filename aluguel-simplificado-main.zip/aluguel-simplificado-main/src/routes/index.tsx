import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { ItemCard } from "@/components/item-card";
import { filtrarDisponiveis, listarCategorias, listarItens } from "@/lib/alugae";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Alugaê — alugue itens de pessoas perto de você" },
      {
        name: "description",
        content:
          "Encontre furadeiras, instrumentos, equipamentos e mais para alugar por dia com pessoas da sua cidade.",
      },
      { property: "og:title", content: "Alugaê — alugue itens perto de você" },
      {
        property: "og:description",
        content: "Busque por categoria e cidade, reserve o período e combine a entrega.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  const [busca, setBusca] = useState("");
  const [buscaAtiva, setBuscaAtiva] = useState("");
  const [cidade, setCidade] = useState("");
  const [categoriaId, setCategoriaId] = useState<string>("");
  const [ini, setIni] = useState("");
  const [fim, setFim] = useState("");
  const periodoOk = !!ini && !!fim && fim >= ini;

  const categorias = useQuery({ queryKey: ["categorias"], queryFn: listarCategorias });
  const itens = useQuery({
    queryKey: ["itens", buscaAtiva, categoriaId, cidade, periodoOk ? ini : "", periodoOk ? fim : ""],
    queryFn: async () => {
      const lista = await listarItens({ busca: buscaAtiva, categoriaId, cidade });
      return periodoOk ? filtrarDisponiveis(lista, ini, fim) : lista;
    },
  });

  return (
    <main className="relative mx-auto max-w-6xl px-5">
      <section className="pt-12 pb-6 sm:pt-16">
        <p className="font-mono text-xs uppercase tracking-[0.25em] text-brand-wood">
          Entre pessoas · pertinho de você
        </p>
        <h1 className="mt-4 max-w-[40ch] text-balance text-4xl font-semibold leading-[1.05] tracking-tight sm:text-5xl">
          Aluga o que seu vizinho tem, devolve a chave na mão.
        </h1>
        <p className="mt-4 max-w-[52ch] text-pretty text-base text-foreground/65">
          Coisas boas, por dia, emprestadas por gente do seu bairro. Sem estoque, sem loja — só o
          jeito simples de vizinhança.
        </p>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            setBuscaAtiva(busca.trim());
          }}
          className="glass-strong mt-8 rounded-3xl p-4 sm:p-5"
        >
          <div className="flex flex-col gap-3 sm:flex-row sm:items-stretch">
            <div className="flex flex-1 items-center gap-3 rounded-2xl bg-background/70 px-4 py-3 ring-1 ring-border">
              <input
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
                className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
                placeholder="O que você quer alugar? Furadeira, trailer, guitarra…"
              />
            </div>
            <div className="flex items-center gap-3 rounded-2xl bg-background/70 px-4 py-3 ring-1 ring-border">
              <input
                value={cidade}
                onChange={(e) => setCidade(e.target.value)}
                className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
                placeholder="Cidade (ex.: Fortaleza)"
              />
            </div>
            <button
              type="submit"
              className="rounded-2xl bg-brand px-6 py-3 text-sm font-medium text-primary-foreground shadow-brand ring-1 ring-brand transition-transform hover:-translate-y-0.5"
            >
              Buscar
            </button>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="font-mono text-[11px] uppercase tracking-[0.15em] text-muted-foreground">
              Filtrar
            </span>
            <button
              type="button"
              onClick={() => setCategoriaId("")}
              className={
                categoriaId === ""
                  ? "rounded-full bg-brand/15 px-3 py-1 text-xs font-medium text-brand-wood ring-1 ring-brand/25"
                  : "rounded-full bg-background/50 px-3 py-1 text-xs text-foreground/70 ring-1 ring-border"
              }
            >
              Todas
            </button>
            {(categorias.data ?? []).map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setCategoriaId(c.id)}
                className={
                  categoriaId === c.id
                    ? "rounded-full bg-brand/15 px-3 py-1 text-xs font-medium text-brand-wood ring-1 ring-brand/25"
                    : "rounded-full bg-background/50 px-3 py-1 text-xs text-foreground/70 ring-1 ring-border"
                }
              >
                {c.nome}
              </button>
            ))}
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <span className="font-mono text-[11px] uppercase tracking-[0.15em]">Disponível de</span>
            <input type="date" value={ini} onChange={(e) => setIni(e.target.value)} className="rounded-xl bg-background/70 px-3 py-1.5 text-foreground ring-1 ring-border" />
            <span>até</span>
            <input type="date" value={fim} min={ini || undefined} onChange={(e) => setFim(e.target.value)} className="rounded-xl bg-background/70 px-3 py-1.5 text-foreground ring-1 ring-border" />
            {ini || fim ? (
              <button type="button" onClick={() => { setIni(""); setFim(""); }} className="underline">
                limpar datas
              </button>
            ) : null}
          </div>
        </form>

        <div className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-2 font-mono text-xs text-muted-foreground">
          <span>{itens.data?.length ?? 0} itens disponíveis</span>
          <span className="h-3 w-px bg-border" />
          <span>preço por dia</span>
          <span className="h-3 w-px bg-border" />
          <span>entrega combinada entre as partes</span>
        </div>
      </section>

      <section className="py-8">
        <div className="mb-5 flex items-end justify-between">
          <h2 className="text-balance text-xl font-semibold tracking-tight">
            Prontos pra emprestar
          </h2>
        </div>

        {itens.isLoading ? (
          <p className="text-sm text-muted-foreground">Carregando itens…</p>
        ) : (itens.data ?? []).length === 0 ? (
          <div className="glass rounded-3xl p-8 text-center">
            <p className="text-sm text-muted-foreground">
              Nenhum item encontrado com esses filtros. Que tal anunciar o primeiro?
            </p>
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {(itens.data ?? []).map((item) => (
              <ItemCard key={item.id} item={item} />
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
