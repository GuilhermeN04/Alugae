import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/como-funciona")({
  head: () => ({
    meta: [
      { title: "Como funciona o Alugaê" },
      {
        name: "description",
        content:
          "Cadastre-se, anuncie ou reserve um item, combine o período, pague e avalie ao devolver.",
      },
      { property: "og:title", content: "Como funciona o Alugaê" },
      {
        property: "og:description",
        content: "O ciclo completo da locação entre pessoas, do anúncio à avaliação.",
      },
    ],
  }),
  component: ComoFunciona,
});

const passos = [
  {
    titulo: "1. Anuncie ou encontre",
    texto:
      "O locador cadastra o item com fotos, categoria, preço por dia, condições de uso e localização. O locatário busca por nome, categoria ou cidade.",
  },
  {
    titulo: "2. Escolha o período",
    texto:
      "Na página do item você seleciona início e fim. O Alugaê confere as datas já reservadas antes de aceitar a solicitação.",
  },
  {
    titulo: "3. Aprovação e pagamento",
    texto:
      "O locador aprova ou recusa a reserva. Aprovada, o locatário registra o pagamento e a locação começa.",
  },
  {
    titulo: "4. Devolução e avaliação",
    texto:
      "Ao devolver, a reserva é encerrada e as duas partes podem se avaliar — a reputação aparece no perfil público.",
  },
];

function ComoFunciona() {
  return (
    <main className="mx-auto max-w-4xl px-5 py-14">
      <p className="font-mono text-xs uppercase tracking-[0.25em] text-brand-wood">Alugaê</p>
      <h1 className="mt-4 text-balance text-4xl font-semibold tracking-tight">
        O ciclo da locação, do anúncio à avaliação.
      </h1>
      <div className="mt-10 grid gap-5 sm:grid-cols-2">
        {passos.map((p) => (
          <article key={p.titulo} className="glass rounded-3xl p-5">
            <h2 className="text-lg font-semibold tracking-tight">{p.titulo}</h2>
            <p className="mt-2 text-sm text-foreground/65">{p.texto}</p>
          </article>
        ))}
      </div>
      <div className="mt-10 flex flex-wrap gap-3">
        <Link
          to="/anunciar"
          className="rounded-full bg-brand px-5 py-3 text-sm font-medium text-primary-foreground shadow-brand"
        >
          Anunciar um item
        </Link>
        <Link
          to="/"
          className="rounded-full bg-background/60 px-5 py-3 text-sm font-medium text-foreground ring-1 ring-border"
        >
          Explorar itens
        </Link>
      </div>
    </main>
  );
}
