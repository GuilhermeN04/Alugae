import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";

export type Papel = "locador" | "locatario";
export const nomePapel: Record<Papel, string> = { locador: "Locador", locatario: "Locatário" };

export function usePapeis() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const q = useQuery({
    queryKey: ["papeis", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("user_roles").select("role").eq("user_id", user!.id);
      if (error) throw error;
      return (data ?? []).map((r) => r.role as Papel);
    },
  });
  const alternar = useMutation({
    mutationFn: async ({ papel, ativo }: { papel: Papel; ativo: boolean }) => {
      if (!user) return;
      const { error } = ativo
        ? await supabase.from("user_roles").insert({ user_id: user.id, role: papel })
        : await supabase.from("user_roles").delete().eq("user_id", user.id).eq("role", papel);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["papeis", user?.id] }),
  });
  const papeis = q.data ?? [];
  return { papeis, carregando: !user || q.isLoading, tem: (p: Papel) => papeis.includes(p), alternar };
}

export function ExigePapel({ papel, children }: { papel: Papel; children: ReactNode }) {
  const { tem, carregando, alternar } = usePapeis();
  if (carregando) return <main className="mx-auto max-w-4xl px-5 py-16 text-sm text-muted-foreground">Carregando…</main>;
  if (tem(papel)) return <>{children}</>;
  const outro: Papel = papel === "locador" ? "locatario" : "locador";
  return (
    <main className="mx-auto max-w-md px-5 py-16">
      <div className="glass-strong rounded-3xl p-6">
        <h1 className="text-xl font-semibold tracking-tight">Área do {nomePapel[papel].toLowerCase()}</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {papel === "locador"
            ? "Esta área é para quem anuncia itens. Ative o perfil de locador para anunciar e receber reservas."
            : "Esta área é para quem aluga itens. Ative o perfil de locatário para fazer reservas."}
        </p>
        <button
          disabled={alternar.isPending}
          onClick={() => alternar.mutate({ papel, ativo: true })}
          className="mt-4 w-full rounded-2xl bg-brand py-3 text-sm font-medium text-primary-foreground shadow-brand disabled:opacity-60"
        >
          Ativar perfil de {nomePapel[papel].toLowerCase()}
        </button>
        <Link
          to={outro === "locador" ? "/painel" : "/reservas"}
          className="mt-3 block text-center text-sm text-brand-wood underline-offset-4 hover:underline"
        >
          Ir para o painel do {nomePapel[outro].toLowerCase()}
        </Link>
      </div>
    </main>
  );
}
