import { useState } from "react";

export function FormAvaliacao({
  titulo,
  pendente,
  onEnviar,
}: {
  titulo: string;
  pendente: boolean;
  onEnviar: (nota: number, comentario: string) => void;
}) {
  const [nota, setNota] = useState(5);
  const [comentario, setComentario] = useState("");

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        onEnviar(nota, comentario);
      }}
      className="mt-4 space-y-3 rounded-2xl border border-border p-4"
    >
      <p className="text-sm font-medium">{titulo}</p>
      <label className="block text-xs text-muted-foreground">
        Nota
        <select className="field mt-1" value={nota} onChange={(e) => setNota(Number(e.target.value))}>
          {[5, 4, 3, 2, 1].map((n) => (
            <option key={n} value={n}>
              {n} / 5
            </option>
          ))}
        </select>
      </label>
      <label className="block text-xs text-muted-foreground">
        Comentário
        <textarea
          rows={2}
          className="field mt-1"
          placeholder="Como foi a retirada e a devolução?"
          value={comentario}
          onChange={(e) => setComentario(e.target.value)}
        />
      </label>
      <button
        type="submit"
        disabled={pendente}
        className="rounded-xl bg-brand px-4 py-2 text-xs font-medium text-primary-foreground shadow-brand disabled:opacity-60"
      >
        Enviar avaliação
      </button>
    </form>
  );
}
