import { Link } from "@tanstack/react-router";
import { BrandMark } from "./brand-mark";

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-background/60 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl flex-col gap-3 px-5 py-8 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <span className="grid size-7 place-items-center rounded-lg bg-brand text-primary-foreground">
            <BrandMark className="size-3.5 fill-current" />
          </span>
          <span className="text-sm font-semibold">Alugaê</span>
        </div>
        <p className="max-w-[46ch] text-pretty text-sm text-muted-foreground">
          Aluguel temporário entre pessoas. Você pega, usa, devolve — a chave na mão.
        </p>
        <div className="flex gap-5 text-sm text-foreground/60">
          <Link to="/anunciar" className="hover:text-foreground">
            Anunciar
          </Link>
          <Link to="/como-funciona" className="hover:text-foreground">
            Como funciona
          </Link>
        </div>
      </div>
    </footer>
  );
}
