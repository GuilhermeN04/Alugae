import { Link, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { BrandMark } from "./brand-mark";

export function SiteHeader() {
  const { user } = useAuth();
  const navigate = useNavigate();

  async function sair() {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  }

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/60 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <Link to="/" className="flex items-center gap-2.5">
          <span className="grid size-8 place-items-center rounded-xl bg-brand text-primary-foreground shadow-brand">
            <BrandMark className="size-4 fill-current" />
          </span>
          <span className="text-lg font-semibold tracking-tight">Alugaê</span>
        </Link>

        <nav className="hidden items-center gap-7 text-sm text-foreground/70 md:flex">
          <Link to="/" className="hover:text-foreground" activeProps={{ className: "text-foreground" }}>
            Explorar
          </Link>
          <Link to="/anunciar" className="hover:text-foreground">
            Anunciar
          </Link>
          <Link to="/como-funciona" className="hover:text-foreground">
            Como funciona
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          {user ? (
            <>
              <Link
                to="/painel"
                className="hidden rounded-full px-3 py-2 text-sm text-foreground/70 hover:text-foreground sm:block"
              >
                Meu painel
              </Link>
              <Link
                to="/conta"
                className="hidden rounded-full px-3 py-2 text-sm text-foreground/70 hover:text-foreground sm:block"
              >
                Minha conta
              </Link>
              <button
                onClick={sair}
                className="rounded-full bg-ink px-4 py-2 text-sm font-medium text-cream transition-transform hover:-translate-y-0.5"
              >
                Sair
              </button>
            </>
          ) : (
            <>
              <Link
                to="/auth"
                className="hidden rounded-full px-3 py-2 text-sm text-foreground/70 hover:text-foreground sm:block"
              >
                Entrar
              </Link>
              <Link
                to="/anunciar"
                className="rounded-full bg-ink px-4 py-2 text-sm font-medium text-cream transition-transform hover:-translate-y-0.5"
              >
                Anunciar grátis
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
