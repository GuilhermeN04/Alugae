import { useState } from "react";

type Periodo = { data_inicio: string; data_fim: string };

const iso = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

const dentro = (dia: string, ps: Periodo[]) =>
  ps.some((p) => dia >= p.data_inicio && dia <= p.data_fim);

export function CalendarioDisponibilidade({
  reservados,
  bloqueados,
  onAlternar,
}: {
  reservados: Periodo[];
  bloqueados: Periodo[];
  onAlternar?: (dia: string) => void;
}) {
  const hoje = new Date();
  const [mes, setMes] = useState(new Date(hoje.getFullYear(), hoje.getMonth(), 1));
  const hojeIso = iso(hoje);
  const primeiro = mes.getDay();
  const total = new Date(mes.getFullYear(), mes.getMonth() + 1, 0).getDate();
  const celulas: (string | null)[] = [
    ...Array(primeiro).fill(null),
    ...Array.from({ length: total }, (_, i) => iso(new Date(mes.getFullYear(), mes.getMonth(), i + 1))),
  ];
  const mudar = (n: number) => setMes(new Date(mes.getFullYear(), mes.getMonth() + n, 1));

  return (
    <div className="rounded-2xl bg-background/70 p-4 ring-1 ring-border">
      <div className="flex items-center justify-between">
        <button type="button" onClick={() => mudar(-1)} className="rounded-lg px-2 py-1 text-sm hover:bg-secondary" aria-label="Mês anterior">
          ‹
        </button>
        <p className="text-sm font-medium capitalize">
          {mes.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}
        </p>
        <button type="button" onClick={() => mudar(1)} className="rounded-lg px-2 py-1 text-sm hover:bg-secondary" aria-label="Próximo mês">
          ›
        </button>
      </div>
      <div className="mt-3 grid grid-cols-7 gap-1 text-center font-mono text-[10px] uppercase text-muted-foreground">
        {["D", "S", "T", "Q", "Q", "S", "S"].map((d, i) => (
          <span key={i}>{d}</span>
        ))}
      </div>
      <div className="mt-1 grid grid-cols-7 gap-1">
        {celulas.map((dia, i) => {
          if (!dia) return <span key={i} />;
          const passado = dia < hojeIso;
          const reservado = dentro(dia, reservados);
          const bloqueado = dentro(dia, bloqueados);
          const cls = reservado
            ? "bg-destructive/20 text-destructive"
            : bloqueado
              ? "bg-muted text-muted-foreground line-through"
              : "bg-brand/10 text-foreground";
          const clicavel = !!onAlternar && !passado && !reservado;
          return (
            <button
              key={dia}
              type="button"
              disabled={!clicavel}
              onClick={() => onAlternar?.(dia)}
              title={reservado ? "Reservado" : bloqueado ? "Indisponível" : "Livre"}
              className={`aspect-square rounded-lg text-xs ${cls} ${passado ? "opacity-40" : ""} ${clicavel ? "hover:ring-2 hover:ring-brand" : "cursor-default"}`}
            >
              {Number(dia.slice(8))}
            </button>
          );
        })}
      </div>
      <div className="mt-3 flex flex-wrap gap-3 font-mono text-[10px] text-muted-foreground">
        <span className="flex items-center gap-1"><i className="h-2.5 w-2.5 rounded bg-brand/20" /> livre</span>
        <span className="flex items-center gap-1"><i className="h-2.5 w-2.5 rounded bg-destructive/30" /> reservado</span>
        <span className="flex items-center gap-1"><i className="h-2.5 w-2.5 rounded bg-muted" /> indisponível</span>
      </div>
    </div>
  );
}
