export function BrandMark({ className = "size-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 20 20" className={className} aria-hidden="true">
      <circle cx="6.5" cy="10" r="3" />
      <path d="M8.5 10h8.5a1.6 1.6 0 1 0 0-3.2 1.6 1.6 0 1 0 0 3.2h-1.6a1.6 1.6 0 1 0 0 3.2H8.5a3 3 0 1 1 0-3.2z" />
    </svg>
  );
}
