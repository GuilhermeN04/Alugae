import { supabase } from "@/integrations/supabase/client";

export type Categoria = { id: string; nome: string; slug: string };

export type ItemRow = {
  id: string;
  titulo: string;
  descricao: string;
  condicoes_uso: string | null;
  preco_dia: number;
  cidade: string;
  bairro: string | null;
  imagem_url: string | null;
  ativo: boolean;
  locador_id: string;
  categoria_id: string | null;
  created_at: string;
};

export type ItemComRelacoes = ItemRow & {
  categorias: { nome: string; slug: string } | null;
  profiles: { id: string; nome: string; cidade: string | null } | null;
};

const ITEM_SELECT =
  "*, categorias(nome, slug), profiles!itens_locador_id_fkey(id, nome, cidade)";

export async function listarCategorias(): Promise<Categoria[]> {
  const { data, error } = await supabase.from("categorias").select("*").order("nome");
  if (error) throw error;
  return data ?? [];
}

export async function listarItens(filtros: {
  busca?: string;
  categoriaId?: string;
  cidade?: string;
}): Promise<ItemComRelacoes[]> {
  let query = supabase.from("itens").select(ITEM_SELECT).eq("ativo", true);
  if (filtros.busca) query = query.ilike("titulo", `%${filtros.busca}%`);
  if (filtros.categoriaId) query = query.eq("categoria_id", filtros.categoriaId);
  if (filtros.cidade) query = query.ilike("cidade", `%${filtros.cidade}%`);
  const { data, error } = await query.order("created_at", { ascending: false }).limit(60);
  if (error) throw error;
  return (data ?? []) as unknown as ItemComRelacoes[];
}

export async function obterItem(id: string): Promise<ItemComRelacoes | null> {
  const { data, error } = await supabase
    .from("itens")
    .select(ITEM_SELECT)
    .eq("id", id)
    .maybeSingle();
  if (error) throw error;
  return (data as unknown as ItemComRelacoes) ?? null;
}

export async function listarMeusItens(userId: string) {
  const { data, error } = await supabase
    .from("itens")
    .select(ITEM_SELECT)
    .eq("locador_id", userId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as unknown as ItemComRelacoes[];
}

export async function periodosOcupados(itemId: string) {
  const { data, error } = await supabase.rpc("periodos_reservados", { _item_id: itemId });
  if (error) throw error;
  return (data ?? []) as { data_inicio: string; data_fim: string }[];
}

export async function periodosBloqueados(itemId: string) {
  const { data, error } = await supabase
    .from("disponibilidades")
    .select("id, data_inicio, data_fim")
    .eq("item_id", itemId)
    .eq("bloqueado", true);
  if (error) throw error;
  return data ?? [];
}

export async function listarFotos(itemId: string, capa?: string | null): Promise<string[]> {
  const { data, error } = await supabase
    .from("item_imagens")
    .select("url")
    .eq("item_id", itemId)
    .order("ordem");
  if (error) throw error;
  const urls = (data ?? []).map((d) => d.url);
  return urls.length ? urls : capa ? [capa] : [];
}

export async function salvarFotos(itemId: string, urls: string[]) {
  const { error } = await supabase.from("item_imagens").delete().eq("item_id", itemId);
  if (error) throw error;
  if (!urls.length) return;
  const { error: e2 } = await supabase
    .from("item_imagens")
    .insert(urls.map((url, ordem) => ({ item_id: itemId, url, ordem })));
  if (e2) throw e2;
}

const sobrepoe = (a1: string, a2: string, b1: string, b2: string) => a1 <= b2 && b1 <= a2;

/** Mantém só itens livres (sem reserva ativa nem bloqueio) em todo o período. */
export async function filtrarDisponiveis<T extends { id: string }>(itens: T[], inicio: string, fim: string) {
  if (!inicio || !fim || !itens.length) return itens;
  const ids = itens.map((i) => i.id);
  const { data: bloq, error } = await supabase
    .from("disponibilidades")
    .select("item_id, data_inicio, data_fim")
    .in("item_id", ids)
    .eq("bloqueado", true);
  if (error) throw error;
  const ocupados = await Promise.all(ids.map((id) => periodosOcupados(id)));
  return itens.filter((item, idx) => {
    const b = (bloq ?? []).some((p) => p.item_id === item.id && sobrepoe(inicio, fim, p.data_inicio, p.data_fim));
    const r = (ocupados[idx] ?? []).some((p) => sobrepoe(inicio, fim, p.data_inicio, p.data_fim));
    return !b && !r;
  });
}

export async function enviarFotoItem(userId: string, file: File) {
  if (!file.type.startsWith("image/")) throw new Error("Escolha um arquivo de imagem.");
  if (file.size > 5 * 1024 * 1024) throw new Error("A foto deve ter no máximo 5 MB.");
  const ext = file.name.split(".").pop() || "jpg";
  const path = `${userId}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from("itens").upload(path, file, { contentType: file.type });
  if (error) throw error;
  const { data, error: e2 } = await supabase.storage.from("itens").createSignedUrl(path, 60 * 60 * 24 * 365 * 10);
  if (e2) throw e2;
  return data.signedUrl;
}

export type ReservaCompleta = {
  id: string;
  data_inicio: string;
  data_fim: string;
  valor_total: number;
  status: string;
  created_at: string;
  item_id: string;
  locador_id: string;
  locatario_id: string;
  itens: { titulo: string; imagem_url: string | null; preco_dia: number } | null;
  locatario: { id: string; nome: string } | null;
  locador: { id: string; nome: string } | null;
};

const RESERVA_SELECT =
  "*, itens(titulo, imagem_url, preco_dia), locatario:profiles!reservas_locatario_id_fkey(id, nome), locador:profiles!reservas_locador_id_fkey(id, nome)";

export async function listarReservasComoLocador(userId: string) {
  const { data, error } = await supabase
    .from("reservas")
    .select(RESERVA_SELECT)
    .eq("locador_id", userId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as unknown as ReservaCompleta[];
}

export async function listarReservasComoLocatario(userId: string) {
  const { data, error } = await supabase
    .from("reservas")
    .select(RESERVA_SELECT)
    .eq("locatario_id", userId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as unknown as ReservaCompleta[];
}

export async function obterPerfil(id: string) {
  const { data, error } = await supabase.from("profiles").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return data;
}

export async function listarAvaliacoesRecebidas(userId: string) {
  const { data, error } = await supabase
    .from("avaliacoes")
    .select("id, nota, comentario, created_at, autor:profiles!avaliacoes_autor_id_fkey(nome)")
    .eq("avaliado_id", userId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export function diasEntre(inicio: string, fim: string) {
  if (!inicio || !fim) return 0;
  const ms = new Date(fim).getTime() - new Date(inicio).getTime();
  if (Number.isNaN(ms) || ms < 0) return 0;
  return Math.floor(ms / 86400000) + 1;
}

export const moeda = (valor: number) =>
  valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export const statusLabel: Record<string, string> = {
  pendente: "Pendente",
  aprovada: "Aprovada",
  recusada: "Recusada",
  cancelada: "Cancelada",
  em_andamento: "Em andamento",
  devolvido: "Devolvido",
  concluida: "Concluída",
};
