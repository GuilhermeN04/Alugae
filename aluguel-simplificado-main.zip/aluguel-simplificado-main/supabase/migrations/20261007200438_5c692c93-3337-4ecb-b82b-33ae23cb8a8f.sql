create type public.app_role as enum ('locador','locatario');
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
grant select, insert, delete on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "ve proprios papeis" on public.user_roles for select to authenticated using (auth.uid() = user_id);
create policy "adiciona proprio papel" on public.user_roles for insert to authenticated with check (auth.uid() = user_id);
create policy "remove proprio papel" on public.user_roles for delete to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path to 'public'
as $$
declare p text := new.raw_user_meta_data->>'papel';
begin
  insert into public.profiles (id, nome, avatar_url)
  values (new.id, coalesce(new.raw_user_meta_data->>'nome', new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)), new.raw_user_meta_data->>'avatar_url')
  on conflict (id) do nothing;
  if p is null or p in ('locador','ambos') then
    insert into public.user_roles (user_id, role) values (new.id, 'locador') on conflict do nothing;
  end if;
  if p is null or p in ('locatario','ambos') then
    insert into public.user_roles (user_id, role) values (new.id, 'locatario') on conflict do nothing;
  end if;
  return new;
end; $$;
revoke execute on function public.handle_new_user() from public, anon, authenticated;

drop policy "dono cria item" on public.itens;
create policy "locador cria item" on public.itens for insert to authenticated
  with check (auth.uid() = locador_id and public.has_role(auth.uid(), 'locador'));
drop policy "locatario cria reserva" on public.reservas;
create policy "locatario cria reserva" on public.reservas for insert to authenticated
  with check (auth.uid() = locatario_id and public.has_role(auth.uid(), 'locatario'));