create or replace function public.periodos_reservados(_item_id uuid)
returns table(data_inicio date, data_fim date)
language sql stable security definer set search_path = public
as $$
  select r.data_inicio, r.data_fim from public.reservas r
  where r.item_id = _item_id and r.status in ('pendente','aprovada','em_andamento')
$$;
grant execute on function public.periodos_reservados(uuid) to anon, authenticated;