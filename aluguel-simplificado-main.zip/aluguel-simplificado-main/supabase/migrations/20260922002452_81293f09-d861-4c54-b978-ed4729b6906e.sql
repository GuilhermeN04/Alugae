-- enums
create type public.reserva_status as enum ('pendente','aprovada','recusada','cancelada','em_andamento','devolvido','concluida');
create type public.pagamento_status as enum ('pendente','pago','reembolsado');

-- profiles
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text not null default 'Usuário',
  telefone text,
  cidade text,
  bairro text,
  avatar_url text,
  bio text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant select on public.profiles to anon;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "perfis visiveis a todos" on public.profiles for select using (true);
create policy "usuario cria proprio perfil" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "usuario edita proprio perfil" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- categorias
create table public.categorias (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  slug text not null unique,
  created_at timestamptz not null default now()
);
grant select on public.categorias to anon, authenticated;
grant all on public.categorias to service_role;
alter table public.categorias enable row level security;
create policy "categorias publicas" on public.categorias for select using (true);

insert into public.categorias (nome, slug) values
  ('Ferramentas','ferramentas'),
  ('Eletrônicos','eletronicos'),
  ('Esporte','esporte'),
  ('Música','musica'),
  ('Festas','festas'),
  ('Lazer','lazer');

-- itens
create table public.itens (
  id uuid primary key default gen_random_uuid(),
  locador_id uuid not null references public.profiles(id) on delete cascade,
  categoria_id uuid references public.categorias(id) on delete set null,
  titulo text not null,
  descricao text not null default '',
  condicoes_uso text,
  preco_dia numeric(10,2) not null check (preco_dia >= 0),
  cidade text not null default 'Fortaleza',
  bairro text,
  imagem_url text,
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint itens_locador_id_fkey_named check (true)
);
grant select, insert, update, delete on public.itens to authenticated;
grant select on public.itens to anon;
grant all on public.itens to service_role;
alter table public.itens enable row level security;
create policy "itens ativos publicos" on public.itens for select using (ativo = true or auth.uid() = locador_id);
create policy "dono cria item" on public.itens for insert to authenticated with check (auth.uid() = locador_id);
create policy "dono edita item" on public.itens for update to authenticated using (auth.uid() = locador_id) with check (auth.uid() = locador_id);
create policy "dono exclui item" on public.itens for delete to authenticated using (auth.uid() = locador_id);
create index itens_categoria_idx on public.itens (categoria_id);
create index itens_locador_idx on public.itens (locador_id);

-- item_imagens
create table public.item_imagens (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.itens(id) on delete cascade,
  url text not null,
  ordem int not null default 0,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.item_imagens to authenticated;
grant select on public.item_imagens to anon;
grant all on public.item_imagens to service_role;
alter table public.item_imagens enable row level security;
create policy "imagens publicas" on public.item_imagens for select using (true);
create policy "dono gerencia imagens" on public.item_imagens for all to authenticated
  using (exists (select 1 from public.itens i where i.id = item_id and i.locador_id = auth.uid()))
  with check (exists (select 1 from public.itens i where i.id = item_id and i.locador_id = auth.uid()));

-- disponibilidades
create table public.disponibilidades (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.itens(id) on delete cascade,
  data_inicio date not null,
  data_fim date not null,
  bloqueado boolean not null default false,
  created_at timestamptz not null default now(),
  check (data_fim >= data_inicio)
);
grant select, insert, update, delete on public.disponibilidades to authenticated;
grant select on public.disponibilidades to anon;
grant all on public.disponibilidades to service_role;
alter table public.disponibilidades enable row level security;
create policy "disponibilidades publicas" on public.disponibilidades for select using (true);
create policy "dono gerencia disponibilidade" on public.disponibilidades for all to authenticated
  using (exists (select 1 from public.itens i where i.id = item_id and i.locador_id = auth.uid()))
  with check (exists (select 1 from public.itens i where i.id = item_id and i.locador_id = auth.uid()));

-- reservas
create table public.reservas (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.itens(id) on delete cascade,
  locatario_id uuid not null references public.profiles(id) on delete cascade,
  locador_id uuid not null references public.profiles(id) on delete cascade,
  data_inicio date not null,
  data_fim date not null,
  valor_total numeric(10,2) not null default 0,
  status public.reserva_status not null default 'pendente',
  observacoes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (data_fim >= data_inicio)
);
grant select, insert, update on public.reservas to authenticated;
grant all on public.reservas to service_role;
alter table public.reservas enable row level security;
create policy "partes veem reserva" on public.reservas for select to authenticated
  using (auth.uid() = locatario_id or auth.uid() = locador_id);
create policy "locatario cria reserva" on public.reservas for insert to authenticated
  with check (auth.uid() = locatario_id);
create policy "partes atualizam reserva" on public.reservas for update to authenticated
  using (auth.uid() = locatario_id or auth.uid() = locador_id)
  with check (auth.uid() = locatario_id or auth.uid() = locador_id);
create index reservas_item_idx on public.reservas (item_id);

-- pagamentos
create table public.pagamentos (
  id uuid primary key default gen_random_uuid(),
  reserva_id uuid not null unique references public.reservas(id) on delete cascade,
  valor numeric(10,2) not null,
  metodo text not null default 'pix',
  status public.pagamento_status not null default 'pendente',
  pago_em timestamptz,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.pagamentos to authenticated;
grant all on public.pagamentos to service_role;
alter table public.pagamentos enable row level security;
create policy "partes veem pagamento" on public.pagamentos for select to authenticated
  using (exists (select 1 from public.reservas r where r.id = reserva_id and (r.locatario_id = auth.uid() or r.locador_id = auth.uid())));
create policy "partes registram pagamento" on public.pagamentos for insert to authenticated
  with check (exists (select 1 from public.reservas r where r.id = reserva_id and (r.locatario_id = auth.uid() or r.locador_id = auth.uid())));
create policy "partes atualizam pagamento" on public.pagamentos for update to authenticated
  using (exists (select 1 from public.reservas r where r.id = reserva_id and (r.locatario_id = auth.uid() or r.locador_id = auth.uid())))
  with check (exists (select 1 from public.reservas r where r.id = reserva_id and (r.locatario_id = auth.uid() or r.locador_id = auth.uid())));

-- avaliacoes
create table public.avaliacoes (
  id uuid primary key default gen_random_uuid(),
  reserva_id uuid not null references public.reservas(id) on delete cascade,
  autor_id uuid not null references public.profiles(id) on delete cascade,
  avaliado_id uuid not null references public.profiles(id) on delete cascade,
  nota int not null check (nota between 1 and 5),
  comentario text,
  created_at timestamptz not null default now(),
  unique (reserva_id, autor_id)
);
grant select, insert on public.avaliacoes to authenticated;
grant select on public.avaliacoes to anon;
grant all on public.avaliacoes to service_role;
alter table public.avaliacoes enable row level security;
create policy "avaliacoes publicas" on public.avaliacoes for select using (true);
create policy "autor cria avaliacao" on public.avaliacoes for insert to authenticated with check (auth.uid() = autor_id);

-- updated_at
create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end; $$;
create trigger profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger itens_updated_at before update on public.itens for each row execute function public.set_updated_at();
create trigger reservas_updated_at before update on public.reservas for each row execute function public.set_updated_at();

-- perfil automatico
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, nome, avatar_url)
  values (new.id, coalesce(new.raw_user_meta_data->>'nome', new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)), new.raw_user_meta_data->>'avatar_url')
  on conflict (id) do nothing;
  return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
