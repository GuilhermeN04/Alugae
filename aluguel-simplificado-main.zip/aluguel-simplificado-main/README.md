# Aluguel Simplificado

Este é o alugâe,preciso que você faça uma aplicação web e ultilize esse projeto desenrola.main como base,adapte o desenrola de acordo com o documento muda alguma coisas de design nome da aplicação e outras necessidades requisitadas no documento,e crie o banco de dados.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/ea9980ff-ef3e-423c-b682-717e05b95240).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
